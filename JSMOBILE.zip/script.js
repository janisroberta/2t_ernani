/**
 * FUNÇÕES: São blocos de código que podem ser reaproveitados
 * Funções podem ou não ter nomes
 * Podem ou não receber parâmetros
 */
// CRIAR OU DECLARAR FUNÇÕES
function dizOla(nome) {
  // código
  console.log('Olá!' + nome)
}
// CHAMAR FUNÇÕES
//dizOla('Robertinha 244')
//dizOla('Vitorinha 244')
//dizOla('natalinha 244')
// + - * /
// ADIÇÃO
function somaDoisNumeros(x, y) {
  const soma = x + y
  console.log(soma)
}
function subtraiDoisNumeros(x, y) {
  const subtrai = x - y
  console.log(subtrai)
}
function multiplicaDoisNumeros(x, y) {
  const multiplica = x * y
  console.log(multiplica)
}
function divideDoisNumeros(x, y) {
  const divide = x / y
  console.log(divide)
}
somaDoisNumeros(5, 9)
multiplicaDoisNumeros(7, 9)
subtraiDoisNumeros(7, 9)
divideDoisNumeros(7, 50)

// SUBTRAÇÃO

// MULTIPLICAÇÃO

// DIVISÃO

// ADIÇÃO

