//selecionar com queryselector
const verde = document.querySelector('.verde')
const amarelo = document.querySelector('.amarelo')
const vermelho = document.querySelector('.vermelho')
const conteudo = document.querySelector('.conteudo ')
const bigtext = document.querySelector('.big-text')


vermelho.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'red'
  bigtext.style.color = '#fff'
})
verde.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'green'
  bigtext.style.color = '#fff'
})

amarelo.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'yellow'
  bigtext.style.color = '#fff'
})
