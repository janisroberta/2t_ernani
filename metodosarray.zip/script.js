// MÉTODOS DE ARRAY
const comidas = ['churrasco', 'pizza']
comidas[3] = 'shushi' // MANUAL 
comidas.push('beringela') // EMPURRANDO UM VALOR PARA O FINAL DA LISTA
comidas.pop() // RETIRA UM VALOR DO FINAL DA LISTA
comidas.shift()// RETIRA UM ELEMENTO DO INICIO 
comidas.unshift("Mamão")// INSERIR UM ITEM NO INICIO DA LISTA

console.log(comidas.length) // CONTAGEM DO ITENS 

console.log(comidas)