




const titulo = document.getElementById('titulo');
const paragrafo = document.getElementById('paragrafo')
const novoTitulo = "Titulo Modificador";
const novoParagrafo = "Paragrafo Modificador";


titulo.innerHTML = novoTitulo;
paragrafo.innerText = novoParagrafo

const roupa = 'camiseta'
const roupas = ['Camiseta', 'calaça', 'vestido', 'blusa']

const precos = [50, 100, 150, 200]
const idades = [1, 25, 65, 28]
const misto = ['Manga', 33, 'Camaro', false]



console.log(roupa)
console.log(roupas)
console.log(roupas[3])
roupas[20] = 'amor'
console.log(roupas[20])

for (var i = 0; i <= 3; i++) {

  console.log(roupas[i])
}
for (var j = 0; j <= 3; j++) {
  console.log(precos[j])

} 